CHENLELAND interaction GIFs
Six simplified chibi animations based on the user-provided illustration reference.
Each GIF: 256 x 256, six frames, 960 ms loop. PNG files are reduced-motion stills.
Actions: high-five, drawing, basketball pass, singing, photo, dance.
